import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'grid-page',
  templateUrl: 'grid.html'
})
export class GridPage {

  constructor(public nav: NavController) {}

}
