export class ListModel {
  name: string;
  image: string;
  description: string;
}
export class List2Model {
  items: Array<ListModel>;
}
