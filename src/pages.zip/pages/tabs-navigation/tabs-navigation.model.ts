export class LoginModel {
  success: string;
}

export class LoginContentModel{
  email: string;
  password: string;
  uid: string;
}
